package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class MainController {
	
	@FXML
	private TextField output;
	private long numb1 = 0;
	private String operator = "";
	private boolean begin = true;
	
	private Calculate calc = new Calculate();
	
	@FXML
	   private void numbers(ActionEvent event) {
	       if (begin) {
	           
	    	   output.setText("");
	           begin = false;
	       }

	       String value = ((Button)event.getSource()).getText();
	       output.setText(output.getText() + value);
	   }
	
	 @FXML
	   private void operate(ActionEvent event) {
	       String value = ((Button)event.getSource()).getText();

	       if (!"=".equals(value)) {
	           if (!operator.isEmpty())
	               return;

	           operator = value;
	           numb1 = Long.parseLong(output.getText());
	           output.setText("");
	       }
	       else {
	           if (operator.isEmpty())
	               return;

	           output.setText(String.valueOf(calc.calculate(numb1, Long.parseLong(output.getText()), operator)));
	           operator = "";
	           begin = true;
	       }
	
	
	
	 }
}

