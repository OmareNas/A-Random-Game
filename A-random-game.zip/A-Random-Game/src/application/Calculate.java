package application;

public class Calculate {
	
	public long calculate(long numb1, long numb2, String operator) {
        switch (operator) {
            case "+":
                return numb1 + numb2;
            case "-":
                return numb1 - numb2;
            case "*":
                return numb1 * numb2;
            
        }

        System.out.println("Unknown operator - " + operator);
        return 0;
    }

	

}
